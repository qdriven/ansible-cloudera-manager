python  wd_setup_cdh.py
python  cdh_update_mgmtConfig.py
python  service_hdfs_enableHa.py
python  service_yarn_enableHa.py
python service_kerbebos_enable.py
python service_ldap_enable.py
