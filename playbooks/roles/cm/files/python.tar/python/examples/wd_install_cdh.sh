python wd.cdh.setup.py
python wd.mght.py
