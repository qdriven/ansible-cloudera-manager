import ConfigParser
import json

from cm_api.api_client import ApiResource
from cm_api.endpoints.cms import ClouderaManager
# Configuration

# Prep for reading config props from external file
CONFIG = ConfigParser.ConfigParser()
CONFIG.read("clouderaconfig.ini")
service_types_and_names = json.loads(CONFIG.get("CM", "service.types.and.names"))

cm_host = CONFIG.get("CM", "cm.host")
CM_HOST  =cm_host
cm_version = CONFIG.get("CM", "cm.version")
cm_port = CONFIG.get("CM", "cm.port")
host_list = CONFIG.get("CM","host.list").split(',')

cluster_name = CONFIG.get("CM","cluster.name")
cdh_version = CONFIG.get("CM","cdh.version")  # also valid: "CDH4"
cdh_version_number = CONFIG.get("CM","cdh.version.number")  # also valid: 4
hive_metastore_host = CONFIG.get("CM","hive.metastore.host")
hive_metastore_name = CONFIG.get("CM","hive.metastore.name")
hive_metastore_password = CONFIG.get("CM","hive.metastore.password")  # enter password here
hive_metastore_database_type = CONFIG.get("CM","hive.metastore.database.type")
hive_metastore_database_port = CONFIG.get("CM","hive.metastore.database.port")

cm_username = CONFIG.get("CM", "cm.username")
cm_password = CONFIG.get("CM", "cm.password")
cm_service_name = CONFIG.get("CM", "cm.service.name")
host_username = CONFIG.get("CM", "host.username")
host_password = CONFIG.get("CM", "host.password")
cm_repo_url = CONFIG.get("CM", "cm.repo.url")

CM_CONFIG = {
    'REMOTE_PARCEL_REPO_URLS': CONFIG.get("CM", "remote.parcel.repo.urls")
}
print CM_CONFIG

standbyNnHost =  CONFIG.get("HDFS","ha.namenode.standbyNnHost")

# get namenode and datanode dir
dfs_name_dir_list = CONFIG.get("HDFS", "dfs.name.dir.list")

enableNnHaArguments = {
    "standbyNnName": CONFIG.get("HDFS", "hdfs.standby.namenode.name"),
    "nameservice": CONFIG.get("HDFS", "hdfs.nameservice.name"),
    "qjName": CONFIG.get("HDFS", "hdfs.qj.name"),
    "activeFcName": CONFIG.get("HDFS", "hdfs.activeFc.name"),
    "standbyFcName": CONFIG.get("HDFS", "hdfs.standbyFc.name"),
    "forceInitZNode": CONFIG.get("HDFS", "hdfs.forceInitZNode"),
    "clearExistingStandbyNameDirs": CONFIG.get("HDFS", "hdfs.clearExistingStandbyNameDirs"),
    "clearExistingJnEditsDir": CONFIG.get("HDFS", "hdfs.clearExistingJnEditsDir")
}

jn_hosts_list=CONFIG.get("HDFS", "hdfs.jn.hostsList").split(',')

jn_edits_dir=CONFIG.get("HDFS", "hdfs.jn.editsDir")

"""
doc:http://*:7180/static/apidocs/path__clusters_-clusterName-_services_-serviceName-_commands_hdfsEnableNnHa.html
"""
def enable_hdfsNn_Ha():
    api = ApiResource(cm_host, cm_port, cm_username, cm_password, version=cm_version)

    #construct dict for hostname -> hostid
    hostname2id={}
    for host in  api.get_all_hosts():
        hostname2id[host.hostname] =host.hostId
        print host.hostname+":"+hostname2id[host.hostname]

    # get the CM instance
    cm = ClouderaManager(api)
    cluster = api.get_cluster(cluster_name)
    hdfs_service_name=service_types_and_names["HDFS"]
    hdfs_service = cluster.get_service(hdfs_service_name)

    #create role: JOURNALNODE   dfs_journalnode_edits_dir:/dfs/jn
    jn_role = None
    for r in hdfs_service.get_all_roles():
        if r.type == "JOURNALNODE":
            jn_role = r
            print "JOURNALNODE"
        if r.type == "NAMENODE":
            print "namenode name:"+r.name 
            enableNnHaArguments["activeNnName"]=r.name
 
    if jn_role == None:
        print "No JOURNALNODE role found,now create it!"
        #hdfs_service.create_role("{0}-JOURNALNODE-BASE".format(hdfs_service_name), "JOURNALNODE",host_list[:3])


    jn_rcg =hdfs_service.get_role_config_group("{0}-JOURNALNODE-BASE".format(hdfs_service_name))

    #print jn_rcg.get_config(view='full')
    print jn_rcg.get_config()


    enableNnHaArguments["zkServiceName"]=service_types_and_names["ZOOKEEPER"]

    #standbyNnHostId  Id of the host on which new Standby NameNode will be created.
    enableNnHaArguments["standbyNnHostId"]=hostname2id[standbyNnHost]

    #"jns"   :	 "array of jns    (apiJournalNodeArguments)

    jnhosts=jn_hosts_list
    enableNnHaArguments["jns"] =[]
    flag=1
    for host in jnhosts:
        jn= {}
        jn["jnEditsDir"]=jn_edits_dir
        jn["jnName"] ="jn"+str(flag)
        flag = flag +1
        jn["jnHostId"]=hostname2id[host]
        enableNnHaArguments["jns"].append(jn)

    cmd=hdfs_service._cmd("hdfsEnableNnHa",data=enableNnHaArguments)
    while cmd.success == None:
        cmd = cmd.fetch()

    if cmd.success != True:
        print "hdfsEnableNnHa failed: " + cmd.resultMessage()
        exit(0)

    # update namenode configuration
    namenode_service_name=service_types_and_names["HDFS"]
    namenode_service = cluster.get_service(namenode_service_name)

    groupconfig = namenode_service.get_role_config_group("HDFS-NAMENODE-BASE")
    groupconfig.update_config({
        "dfs_name_dir_list":dfs_name_dir_list
    })

    cluster.deploy_client_config().wait()
    print "hdfsEnableNnHa successfully executed. pleas enjoy HA!"

def main():
    enable_hdfsNn_Ha()


if __name__ == "__main__":
    main()

