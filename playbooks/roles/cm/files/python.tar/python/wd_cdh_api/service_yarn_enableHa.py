import ConfigParser
import json
import socket, sys, time, ConfigParser, csv, pprint, urllib2

from cm_api.api_client import ApiResource
from cm_api.endpoints.cms import ClouderaManager
# Configuration

# Prep for reading config props from external file
CONFIG = ConfigParser.ConfigParser()
CONFIG.read("clouderaconfig.ini")
service_types_and_names = json.loads(CONFIG.get("CM", "service.types.and.names"))

cm_host = CONFIG.get("CM", "cm.host")
CM_HOST  =cm_host
cm_port = CONFIG.get("CM", "cm.port")
cm_version = CONFIG.get("CM", "cm.version")
host_list = CONFIG.get("CM","host.list").split(',')

cluster_name = CONFIG.get("CM","cluster.name")

cm_username = CONFIG.get("CM", "cm.username")
cm_password = CONFIG.get("CM", "cm.password")
cm_service_name = CONFIG.get("CM", "cm.service.name")
host_username = CONFIG.get("CM", "host.username")
host_password = CONFIG.get("CM", "host.password")
cm_repo_url = CONFIG.get("CM", "cm.repo.url")

hdfs_gw_hosts=CONFIG.get("HDFS", "hdfs.gw.hosts").split(",")
hbase_gw_hosts=CONFIG.get("HDFS", "hdfs.gw.hosts").split(",")
yarn_service_name=service_types_and_names["YARN"]

yarn_resourcemanager_host = host_list[1]
yarn_resourcemanager_server_name = "RESOURCEMANAGER1"

yarn_nodemanager_local_dirs = CONFIG.get("YARN", "yarn.nodemanager.local.dirs")
yarn_nodemanager_log_dirs = CONFIG.get("YARN", "yarn.nodemanager.log.dirs")

enableRmHaArgs={
    "newRmHostId":CONFIG.get("YARN", "yarn.resouremanager.secondery"),
    "newRmRoleName":"{0}_SECONDARRESOURCEMANAGER".format(yarn_service_name),
    "zkServiceName":service_types_and_names["ZOOKEEPER"]
}



def enable_yarn_ha():

    api = ApiResource(cm_host, cm_port, cm_username, cm_password, version=cm_version)

    cm = ClouderaManager(api)

    hostname2id={}
    for host in  api.get_all_hosts():
        hostname2id[host.hostname] =host.hostId
        print host.hostname+":"+hostname2id[host.hostname]

    cluster = api.get_cluster(cluster_name)
    yarn_service = cluster.get_service(yarn_service_name)


    for r in yarn_service.get_all_roles():
        if r.type == "RESOURCEMANAGER":
            yarn_service.delete_role(r.name)

    rm_name_patten= "{0}-" + yarn_resourcemanager_server_name
    yarn_service.create_role(rm_name_patten.format(yarn_service_name),"RESOURCEMANAGER",yarn_resourcemanager_host)


    cluster.deploy_client_config().wait()
   
    cmd = yarn_service._cmd("enableRmHa",data=enableRmHaArgs,
                            params={"serviceName":yarn_service_name, "clusterName" : cluster_name })

    # update yarn configuration
    groupconfig = yarn_service.get_role_config_group("yarn-NODEMANAGER-BASE")
    groupconfig.update_config({
        "yarn_nodemanager_local_dirs":yarn_nodemanager_local_dirs,
        "yarn_nodemanager_log_dirs":yarn_nodemanager_log_dirs
    })

    print cmd
    while cmd.success == None:
        cmd = cmd.fetch()

    if cmd.success != True:
        print " yarn rm a failed:"
        exit(0)
    cluster.deploy_client_config().wait()
    print "yarn rm  successfully executed. Please enjoy HA!"




def main():
    enable_yarn_ha()



if __name__ == "__main__":
    main()

