# Licensed to Cloudera, Inc. under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  Cloudera, Inc. licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from cm_api.api_client import ApiResource
from cm_api.endpoints.clusters import ApiCluster
from cm_api.endpoints.clusters import create_cluster
from cm_api.endpoints.clusters import *
from cm_api.endpoints.parcels import ApiParcel
from cm_api.endpoints.parcels import get_parcel
from cm_api.endpoints.cms import ClouderaManager
from cm_api.endpoints.services import ApiService, ApiServiceSetupInfo
from cm_api.endpoints.services import create_service
from cm_api.endpoints.types import ApiCommand, ApiRoleConfigGroupRef
from cm_api.endpoints.role_config_groups import get_role_config_group
from cm_api.endpoints.role_config_groups import ApiRoleConfigGroup
from cm_api.endpoints.roles import ApiRole
from time import sleep

import re

# Configuration

cm_host = "testbig1.wanda.cn"
CM_HOST  =cm_host
cm_port = 7180
host_list = ['testbig1.wanda.cn', 'testbig2.wanda.cn', 'testbig3.wanda.cn', 'testbig4.wanda.cn']
cluster_name = "Cluster1"
cdh_version = "CDH5"  # also valid: "CDH4"
cdh_version_number = "5"  # also valid: 4
hive_metastore_host = cm_host
hive_metastore_name = "metastore"
hive_metastore_password = "123456"  # enter password here
hive_metastore_database_type = "mysql"
hive_metastore_database_port = 3306
cm_username = "admin"
cm_password = "admin"
cm_service_name = "mgmt"
host_username = "root"
host_list = ['testbig1.wanda.cn', 'testbig2.wanda.cn', 'testbig3.wanda.cn', 'testbig4.wanda.cn']
host_password = "bigdata"
cm_repo_url = "http://10.214.128.30/cm/"

CM_CONFIG = {
    'REMOTE_PARCEL_REPO_URLS': 'http://10.214.128.30/cdh/'
}

AMON_ROLENAME = "ACTIVITYMONITOR"
AMON_ROLE_CONFIG = {"firehose_database_host": hive_metastore_host,\
    		    "firehose_database_user": "amon",\
                    "firehose_database_password": hive_metastore_password,\
                    "firehose_database_type": hive_metastore_database_type,\
                    "firehose_database_name": "amon"}

APUB_ROLENAME = "ALERTPUBLISHER"
APUB_ROLE_CONFIG = {}
ESERV_ROLENAME = "EVENTSERVER"
ESERV_ROLE_CONFIG = {
    'event_server_heapsize': '215964392'}
HMON_ROLENAME = "HOSTMONITOR"
HMON_ROLE_CONFIG = {}
SMON_ROLENAME = "SERVICEMONITOR"
SMON_ROLE_CONFIG = {}
NAV_ROLENAME = "NAVIGATOR"
NAV_ROLE_CONFIG = { "navigator_database_host": hive_metastore_host, \
                    "navigator_database_user": "nav",  \
                    "navigator_database_password": hive_metastore_password,  \
                    "navigator_database_type": hive_metastore_database_type, \
                    "navigator_database_name": "nav"}
NAVMS_ROLENAME = "NAVIGATORMETASERVER"
NAVMS_ROLE_CONFIG = { "nav_metaserver_database_host": hive_metastore_host,  \
                      "nav_metaserver_database_user": "navms",  \
                      "nav_metaserver_database_password": hive_metastore_password,  \
                      "nav_metaserver_database_type": hive_metastore_database_type,  \
                      "nav_metaserver_database_name": "navms"}

RMAN_ROLENAME = "REPORTSMANAGER"

RMAN_ROLE_CONFIG={"headlamp_database_host": "testbig1.wanda.cn",
                  "headlamp_database_name": "rman",  
                  "headlamp_database_user": "rman",  
                  "headlamp_database_password": "123456",  
                  "headlamp_database_type": "mysql"}

def set_up_cluster():
    # get a handle on the instance of CM that we have running
    api = ApiResource(cm_host, cm_port, cm_username, cm_password, version=13)
    cm = ClouderaManager(api)
    # get the CM instance
    def update_role_config(API,CM,TYPE,CONFIG): 
        print("update_role_config") 
        rm_role = None
        for r in CM.get_service().get_all_roles():
             print r.type
             if r.type == TYPE:
                rm_role = r


        if rm_role == None:
           print "No "+TYPE+" role found!"
           exit(0)

        rm_role_group = rm_role.roleConfigGroupRef
        rm_rcg = get_role_config_group(API, rm_role.type, \
                                   rm_role_group.roleConfigGroupName, None)

        rm_rcg.update_config(CONFIG)
        return 
          
    print "get all roles"
    cm_service = cm.get_service()
    for r in cm_service.get_all_roles():
        print r.type

    cm_service = cm.get_service()
    for group in cm_service.get_all_roles():
        print group.type	
        if  group.type  == RMAN_ROLENAME:
            print RMAN_ROLENAME
            update_role_config(api,cm,group.type,RMAN_ROLE_CONFIG)
        elif group.type == AMON_ROLENAME:
            update_role_config(api,cm,group.type,AMON_ROLE_CONFIG)
        elif group.type == APUB_ROLENAME:
            update_role_config(api,cm,group.type,APUB_ROLE_CONFIG)
        elif group.type == ESERV_ROLENAME:
            update_role_config(api,cm,group.type,ESERV_ROLE_CONFIG)
        elif group.type == HMON_ROLENAME:
            update_role_config(api,cm,group.type,HMON_ROLE_CONFIG)
        elif group.type == NAV_ROLENAME:
            update_role_config(api,cm,group.type,NAV_ROLE_CONFIG)
        elif group.type == NAVMS_ROLENAME:
            update_role_config(api,cm,group.type,NAVMS_ROLE_CONFIG)
        elif group.type == SMON_ROLENAME:
            update_role_config(api,cm,group.type,SMON_ROLE_CONFIG)
    cm_service.restart().wait()      

def main():
    set_up_cluster()


if __name__ == "__main__":
    main()

