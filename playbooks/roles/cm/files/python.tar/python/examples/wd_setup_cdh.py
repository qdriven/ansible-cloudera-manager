import ConfigParser
from time import sleep
import socket, sys, time, ConfigParser, csv, pprint, urllib2
from subprocess import Popen, PIPE, STDOUT
from math import log as ln
from cm_api.endpoints.services import ApiService
from optparse import OptionParser
from cm_api.api_client import ApiResource
from cm_api.endpoints.clusters import *
from cm_api.endpoints.cms import ClouderaManager
from cm_api.endpoints.parcels import get_parcel
from cm_api.endpoints.services import ApiServiceSetupInfo
import json
# Configuration

# Prep for reading config props from external file
CONFIG = ConfigParser.ConfigParser()
CONFIG.read("clouderaconfig.ini")
service_types_and_names = json.loads(CONFIG.get("CM", "service.types.and.names"))

cm_host = CONFIG.get("CM", "cm.host")
CM_HOST  =cm_host
cm_port = CONFIG.get("CM", "cm.port")
host_list = CONFIG.get("CM","host.list").split(',')

cluster_name = CONFIG.get("CM","cluster.name")
cdh_version = CONFIG.get("CM","cdh.version")  # also valid: "CDH4"
cdh_version_number = CONFIG.get("CM","cdh.version.number")  # also valid: 4
hive_metastore_host = CONFIG.get("CM","hive.metastore.host")
hive_metastore_name = CONFIG.get("CM","hive.metastore.name")
hive_metastore_password = CONFIG.get("CM","hive.metastore.password")  # enter password here
hive_metastore_database_type = CONFIG.get("CM","hive.metastore.database.type")
hive_metastore_database_port = CONFIG.get("CM","hive.metastore.database.port")

cm_username = CONFIG.get("CM", "cm.username")
cm_password = CONFIG.get("CM", "cm.password")
cm_service_name = CONFIG.get("CM", "cm.service.name")
host_username = CONFIG.get("CM", "host.username")
host_password = CONFIG.get("CM", "host.password")
cm_repo_url = CONFIG.get("CM", "cm.repo.url")

CM_CONFIG = {
    'REMOTE_PARCEL_REPO_URLS': CONFIG.get("CM", "remote.parcel.repo.urls")
}
print CM_CONFIG
hive_config = {"hive_metastore_database_host": hive_metastore_host, \
               "hive_metastore_database_name": hive_metastore_name, \
               "hive_metastore_database_password": hive_metastore_password, \
               "hive_metastore_database_port": hive_metastore_database_port, \
               "hive_metastore_database_type": hive_metastore_database_type}

def set_up_cluster():
    # get a handle on the instance of CM that we have running
    api = ApiResource(cm_host, cm_port, cm_username, cm_password, version=13)

    # get the CM instance
    cm = ClouderaManager(api)
    cm.update_config(CM_CONFIG)
    # activate the CM trial license
    #cm.end_trial()
    #cm.begin_trial()
    # create the management service
    service_setup = ApiServiceSetupInfo(name=cm_service_name, type="MGMT")

    #mgmt=cm.create_mgmt_service(service_setup)


    # install hosts on this CM instance
    
    cmd = cm.host_install(host_username, host_list, password=host_password, cm_repo_url=cm_repo_url)
    print "Installing hosts. This might take a while."
    while cmd.success == None:
        sleep(5)
        cmd = cmd.fetch()

    if cmd.success != True:
        print "cm_host_install failed: " + cmd.resultMessage
        exit(0)
    print "cm_host_install succeeded"
    # first auto-assign roles and auto-configure the CM service
    cm.auto_assign_roles()
    cm.auto_configure()
    # create a cluster on that instance
    # delete_cluster(api,cluster_name)
    cluster = create_cluster(api, cluster_name, cdh_version)

    # add all our hosts to the cluster
    cluster.add_hosts(host_list)
    # get and list all available parcels
    parcels_list = []
    print "Available parcels:"
    for p in cluster.get_all_parcels():
        print '\t' + p.product + ' ' + p.version
        if p.version.startswith(cdh_version_number) and p.product == "CDH":
            parcels_list.append(p)

    if len(parcels_list) == 0:
        print "No " + cdh_version + " parcel found!"
        exit(0)
    cdh_parcel = parcels_list[0]
    for p in parcels_list:
        if p.version > cdh_parcel.version:
            cdh_parcel = p
    # download the parcel

    print "Starting parcel download. This might take a while."
    cmd = cdh_parcel.start_download()
    if cmd.success != True:
        print "Parcel download failed!"
        exit(0)

    # make sure the download finishes
    while cdh_parcel.stage != 'DOWNLOADED':
        sleep(5)
        cdh_parcel = get_parcel(api, cdh_parcel.product, cdh_parcel.version, cluster_name)

    print cdh_parcel.product + ' ' + cdh_parcel.version + " downloaded"

    # distribute the parcel
    print "Starting parcel distribution. This might take a while."
    cmd = cdh_parcel.start_distribution()
    if cmd.success != True:
        print "Parcel distribution failed!"
        exit(0)

    # make sure the distribution finishes
    while cdh_parcel.stage != "DISTRIBUTED":
        sleep(5)
        cdh_parcel = get_parcel(api, cdh_parcel.product, cdh_parcel.version, cluster_name)

    print cdh_parcel.product + ' ' + cdh_parcel.version + " distributed"

    # activate the parcel
    cmd = cdh_parcel.activate()
    if cmd.success != True:
        print "Parcel activation failed!"
        exit(0)

    # make sure the activation finishes
    while cdh_parcel.stage != "ACTIVATED":
        cdh_parcel = get_parcel(api, cdh_parcel.product, cdh_parcel.version, cluster_name)

    print cdh_parcel.product + ' ' + cdh_parcel.version + " activated"

    # inspect hosts and print the result
    print "Inspecting hosts. This might take a few minutes."

    cmd = cm.inspect_hosts()
    while cmd.success == None:
        cmd = cmd.fetch()

    if cmd.success != True:
        print "Host inpsection failed!"
        exit(0)

    print "Hosts successfully inspected: \n" + cmd.resultMessage

    # create all the services we want to add; we will only create one instance
    # of each
    for s in service_types_and_names.keys():
        service = cluster.create_service(service_types_and_names[s], s)

    # we will auto-assign roles; you can manually assign roles using the
    # /clusters/{clusterName}/services/{serviceName}/role endpoint or by using
    # ApiService.createRole()
    cluster.auto_assign_roles()
    cluster.auto_configure()

    # this will set up the Hive and the reports manager databases because we
    # can't auto-configure those two things
    hive = cluster.get_service(service_types_and_names["HIVE"])
    hive_config = {"hive_metastore_database_host": hive_metastore_host, \
                   "hive_metastore_database_name": hive_metastore_name, \
                   "hive_metastore_database_password": hive_metastore_password, \
                   "hive_metastore_database_port": hive_metastore_database_port, \
                   "hive_metastore_database_type": hive_metastore_database_type}
    hive.update_config(hive_config)

    # start the management service
    cm_service = cm.get_service()
    cm_service.start().wait()

    # execute the first run command
    print "Excuting first run command. This might take a while."
    cmd = cluster.first_run()

    while cmd.success == None:
        cmd = cmd.fetch()

    if cmd.success != True:
        print "The first run command failed: " + cmd.resultMessage()
        exit(0)

    print "First run successfully executed. Your cluster has been set up!"


def main():
    set_up_cluster()


if __name__ == "__main__":
    main()
