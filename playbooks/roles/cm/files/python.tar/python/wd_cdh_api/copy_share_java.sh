for i in {1,2,3,4,5,9,10,11}
do  
   scp -r  /usr/share/java testbig$i:/usr/share
done
