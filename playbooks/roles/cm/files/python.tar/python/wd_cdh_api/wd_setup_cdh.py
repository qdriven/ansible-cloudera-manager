import ConfigParser
import ConfigParser
import json
from time import sleep
import os

from cm_api.api_client import ApiResource
from cm_api.endpoints.clusters import *
from cm_api.endpoints.cms import ClouderaManager
from cm_api.endpoints.parcels import get_parcel
from cm_api.endpoints.services import ApiServiceSetupInfo
from cm_api.endpoints.role_config_groups import get_role_config_group


# Configuration

# Prep for reading config props from external file
CONFIG = ConfigParser.ConfigParser()
CONFIG.read("clouderaconfig.ini")
service_types_and_names = json.loads(CONFIG.get("CM", "service.types.and.names"))

cm_host = CONFIG.get("CM", "cm.host")
cm_version=CONFIG.get("CM", "cm.version")
CM_HOST  =cm_host
cm_port = CONFIG.get("CM", "cm.port")
host_list = CONFIG.get("CM","host.list").split(',')

cluster_name = CONFIG.get("CM","cluster.name")
cdh_version = CONFIG.get("CM","cdh.version")  # also valid: "CDH4"
cdh_version_number = CONFIG.get("CM","cdh.version.number")  # also valid: 4
hive_metastore_host = CONFIG.get("CM","hive.metastore.host")
hive_metastoreServer_host = CONFIG.get("CM","hive.metastoreserver.host")
hive_metastore_name = CONFIG.get("CM","hive.metastore.name")
hive_metastore_password = CONFIG.get("CM","hive.metastore.password")  # enter password here
hive_metastore_database_type = CONFIG.get("CM","hive.metastore.database.type")
hive_metastore_database_port = CONFIG.get("CM","hive.metastore.database.port")

cm_username = CONFIG.get("CM", "cm.username")
cm_password = CONFIG.get("CM", "cm.password")
cm_service_name = CONFIG.get("CM", "cm.service.name")
host_username = CONFIG.get("CM", "host.username")
host_password = CONFIG.get("CM", "host.password")
cm_repo_url = CONFIG.get("CM", "cm.repo.url")

CM_CONFIG = {
    'REMOTE_PARCEL_REPO_URLS': CONFIG.get("CM", "remote.parcel.repo.urls")
}
print CM_CONFIG
############################################

AMON_ROLENAME = "ACTIVITYMONITOR"
AMON_ROLE_CONFIG = {"firehose_database_host": hive_metastore_host, \
                    "firehose_database_user": CONFIG.get("CM", "firehose.database.user"), \
                    "firehose_database_password": hive_metastore_password, \
                    "firehose_database_type": hive_metastore_database_type, \
                    "firehose_database_name": CONFIG.get("CM", "firehose.database.name")}

APUB_ROLENAME = "ALERTPUBLISHER"
APUB_ROLE_CONFIG = {}
ESERV_ROLENAME = "EVENTSERVER"
ESERV_ROLE_CONFIG = {
    'event_server_heapsize': CONFIG.get("CM", "event.server.heapsize")}
HMON_ROLENAME = "HOSTMONITOR"
HMON_ROLE_CONFIG = {}
SMON_ROLENAME = "SERVICEMONITOR"
SMON_ROLE_CONFIG = {}
NAV_ROLENAME = "NAVIGATOR"
NAV_ROLE_CONFIG = { "navigator_database_host": hive_metastore_host, \
                    "navigator_database_user": CONFIG.get("CM", "navigator.database.user"), \
                    "navigator_database_password": hive_metastore_password, \
                    "navigator_database_type": hive_metastore_database_type, \
                    "navigator_database_name":CONFIG.get("CM", "navigator.database.name") }
NAVMS_ROLENAME = "NAVIGATORMETASERVER"
NAVMS_ROLE_CONFIG = { "nav_metaserver_database_host": hive_metastore_host, \
                      "nav_metaserver_database_user": CONFIG.get("CM", "nav.metaserver.database.user"), \
                      "nav_metaserver_database_password": hive_metastore_password, \
                      "nav_metaserver_database_type": hive_metastore_database_type, \
                      "nav_metaserver_database_name": CONFIG.get("CM", "nav.metaserver.database.name")}

RMAN_ROLENAME = "REPORTSMANAGER"

RMAN_ROLE_CONFIG={"headlamp_database_host": hive_metastore_host,
                  "headlamp_database_name": CONFIG.get("CM", "headlamp.database.name"),
                  "headlamp_database_user": CONFIG.get("CM", "headlamp.database.user"),
                  "headlamp_database_password": hive_metastore_password,
                  "headlamp_database_type": hive_metastore_database_type}

###########################################





hive_config = {"hive_metastore_database_host": hive_metastore_host, \
               "hive_metastore_database_name": hive_metastore_name, \
               "hive_metastore_database_password": hive_metastore_password, \
               "hive_metastore_database_port": hive_metastore_database_port, \
               "hive_metastore_database_type": hive_metastore_database_type}



############################################

hdfs_namenode_server_name = "namenode"
hdfs_datanode_server_name = "datanode"
hdfs_namenode_host = host_list[1]
hdfs_snn_host  = host_list[2]

hdfs_datanode_host = host_list[3:]

############################################

hdfs_gw_hosts=CONFIG.get("HDFS", "hdfs.gw.hosts").split(",")
hbase_gw_hosts=CONFIG.get("HDFS", "hdfs.gw.hosts").split(",")
hbase_backup_master = CONFIG.get("HBASE", "hbase.backup.master").split(",")
yarn_gw_hosts=CONFIG.get("HDFS", "hdfs.gw.hosts").split(",")
spark_gw_hosts=CONFIG.get("CM", "host.list").split(",")
hive_gw_hosts=CONFIG.get("HDFS", "hdfs.gw.hosts").split(",")

# get namenode and datanode dir
dfs_name_dir_list = CONFIG.get("HDFS", "dfs.name.dir.list")
dfs_data_dir_list = CONFIG.get("HDFS", "dfs.data.dir.list")

zk_add_nodes = CONFIG.get("ZOOKEEPER", "zk.add.nodes").split(",")
zk_data_dir = CONFIG.get("ZOOKEEPER", "zk.data.dir")

############################################
yarn_nodemanager_local_dirs = CONFIG.get("YARN", "yarn.nodemanager.local.dirs")
yarn_nodemanager_log_dirs = CONFIG.get("YARN", "yarn.nodemanager.log.dirs")


impala_daemon_hosts = host_list[3:]
impala_catalogserver_host= CONFIG.get("IMPALA", "impala.catalogserver.host")

hue_database_config={
    "database_host"            : hive_metastore_host,
    "database_password"        : hive_metastore_password,
    "database_type"            : hive_metastore_database_type
}

sentry_database_config={
    "sentry_server_database_host"            : hive_metastore_host,
    "sentry_server_database_password"        : hive_metastore_password,
    "sentry_server_database_type"            : hive_metastore_database_type,
    "sentry_server_database_user"            : "sentry",
    "sentry_server_database_name"            : "sentry"
}

hue_server_host =  CONFIG.get("HUE", "hue.server.host")
oozie_server_host  = CONFIG.get("OOZIE", "oozie.server.host")

sentry_service_name = service_types_and_names["SENTRY"]
sentry_server_host  = CONFIG.get("SENTRY", "sentry.server.host")

solr_server_host = CONFIG.get("SOLR", "solr.server.host")

########################################################


def set_up_mgmt(api,cm):
    # get the CM instance
    def update_role_config(API,CM,TYPE,CONFIG):
        print("update_role_config")
        rm_role = None
        for r in CM.get_service().get_all_roles():
            if r.type == TYPE:
                rm_role = r

        if rm_role == None:
            print "No "+TYPE+" role found!"
            exit(0)
        rm_role_group = rm_role.roleConfigGroupRef
        rm_rcg = get_role_config_group(API, rm_role.type, \
                                       rm_role_group.roleConfigGroupName, None)
        rm_rcg.update_config(CONFIG)
        return

    cm_service = cm.get_service()
    for group in cm_service.get_all_roles():
        print group.type
        if  group.type  == RMAN_ROLENAME:
            print RMAN_ROLENAME
            cm_service.delete_role(group.name)
            cm_service.create_role("RMAN_ROLENAME",group.type, cm_host)
            update_role_config(api,cm,group.type,RMAN_ROLE_CONFIG)
        elif group.type == AMON_ROLENAME:
            cm_service.delete_role(group.name)
            cm_service.create_role("AMON_ROLENAME",group.type, cm_host)
            update_role_config(api,cm,group.type,AMON_ROLE_CONFIG)
        elif group.type == APUB_ROLENAME:
            cm_service.delete_role(group.name)
            cm_service.create_role("APUB_ROLENAME",group.type, cm_host)
            update_role_config(api,cm,group.type,APUB_ROLE_CONFIG)
        elif group.type == ESERV_ROLENAME:
            cm_service.delete_role(group.name)
            cm_service.create_role("ESERV_ROLENAME",group.type, cm_host)
            update_role_config(api,cm,group.type,ESERV_ROLE_CONFIG)
        elif group.type == HMON_ROLENAME:
            cm_service.delete_role(group.name)
            cm_service.create_role("HMON_ROLENAME",group.type, cm_host)
            update_role_config(api,cm,group.type,HMON_ROLE_CONFIG)
        elif group.type == NAV_ROLENAME:
            cm_service.delete_role(group.name)
            cm_service.create_role("NAV_ROLENAME",group.type, cm_host)
            update_role_config(api,cm,group.type,NAV_ROLE_CONFIG)
        elif group.type == NAVMS_ROLENAME:
            cm_service.delete_role(group.name)
            cm_service.create_role("NAVMS_ROLENAME",group.type, cm_host)
            update_role_config(api,cm,group.type,NAVMS_ROLE_CONFIG)
        elif group.type == SMON_ROLENAME:
            cm_service.delete_role(group.name)
            cm_service.create_role("SMON_ROLENAME",group.type, cm_host)
            update_role_config(api,cm,group.type,SMON_ROLE_CONFIG)
    cm.update_all_hosts_config({"java_home":"/usr/java/latest"})


def add_hdfs_roles(cluster):

    hdfs_service_name=service_types_and_names["HDFS"]
    hdfs_service = cluster.get_service(hdfs_service_name)

    for r in hdfs_service.get_all_roles():
        if r.type == "GATEWAY":
            hdfs_service.delete_role(r.name)


    flag=0
    for host in hdfs_gw_hosts:
        flag = flag +1
        try:
            hdfs_service.create_role("{0}-gw-".format(hdfs_service_name) + str(flag),"GATEWAY", host)
        except:
            hdfs_service.delete_role("{0}-gw-".format(hdfs_service_name) + str(flag))
            hdfs_service.create_role("{0}-gw-".format(hdfs_service_name) + str(flag),"GATEWAY", host)

    for r in hdfs_service.get_all_roles():
        if r.type == "HTTFS":
            hdfs_service.delete_role(r.name)
    flag=0
    for host in hdfs_gw_hosts:
        flag = flag +1

        try:
            hdfs_service.create_role("{0}-httpfs-".format(hdfs_service_name) + str(flag),"HTTPFS", host)
        except:
            hdfs_service.delete_role("{0}-httpfs-".format(hdfs_service_name) + str(flag))
            hdfs_service.create_role("{0}-httpfs-".format(hdfs_service_name) + str(flag),"HTTPFS", host)
        hue_service_name = service_types_and_names["HUE"]
        hue_service = cluster.get_service(hue_service_name)
        if flag == 1 :
            hue_service.update_config({"hue_webhdfs":"{0}-httpfs-".format(hdfs_service_name) + str(flag)})





def add_hbase_roles(cluster):
    hbase_service_name=service_types_and_names["HBASE"]
    hbase_service = cluster.get_service(hbase_service_name)

    for r in hbase_service.get_all_roles():
        if r.type == "MASTER":
            hbase_service.delete_role(r.name)
    flag=0
    for host in hbase_backup_master:
        flag = flag +1
        try:
            hbase_service.create_role("{0}-master".format(hbase_service_name) + str(flag),"MASTER", host)
        except:
            hbase_service.delete_role("{0}-master".format(hbase_service_name) + str(flag))
            hbase_service.create_role("{0}-master".format(hbase_service_name) + str(flag),"MASTER", host)

    for r in hbase_service.get_all_roles():
        if r.type == "GATEWAY":
            hbase_service.delete_role(r.name)
    flag=0
    for host in hbase_gw_hosts:
        flag = flag +1
        try:
            hbase_service.create_role("{0}-gw".format(hbase_service_name) + str(flag),"GATEWAY", host)
        except:
            hbase_service.delete_role("{0}-gw".format(hbase_service_name) + str(flag))
            hbase_service.create_role("{0}-gw".format(hbase_service_name) + str(flag),"GATEWAY", host)

    for r in hbase_service.get_all_roles():
        if r.type == "HBASERESTSERVER":
            hbase_service.delete_role(r.name)
    flag=0
    for host in hbase_gw_hosts:
        flag = flag +1
        try:
            hbase_service.create_role("{0}-hbaserestserver".format(hbase_service_name) + str(flag),"HBASERESTSERVER", host)
        except:
            hbase_service.delete_role("{0}-hbaserestserver".format(hbase_service_name) + str(flag))
            hbase_service.create_role("{0}-hbaserestserver".format(hbase_service_name) + str(flag),"HBASERESTSERVER", host)


    for r in hbase_service.get_all_roles():
        if r.type == "HBASETHRIFTSERVER":
            hbase_service.delete_role(r.name)
    flag=0
    for host in hbase_gw_hosts:
        flag = flag +1
        try:
            hbase_service.create_role("{0}-hbasethriftserver".format(hbase_service_name) + str(flag),"HBASETHRIFTSERVER", host)
        except:
            hbase_service.delete_role("{0}-hbasethriftserver".format(hbase_service_name) + str(flag))
            hbase_service.create_role("{0}-hbasethriftserver".format(hbase_service_name) + str(flag),"HBASETHRIFTSERVER", host)



def add_yarn_roles(cluster):
    yarn_service_name=service_types_and_names["YARN"]
    yarn_service = cluster.get_service(yarn_service_name)

    for r in yarn_service.get_all_roles():
        if r.type == "GATEWAY":
            yarn_service.delete_role(r.name)
    flag=0
    for host in yarn_gw_hosts:
        flag = flag +1
        try:
            yarn_service.create_role("{0}-gw-".format(yarn_service_name) + str(flag),"GATEWAY", host)
        except:
            yarn_service.delete_role("{0}-gw-".format(yarn_service_name) + str(flag))
            yarn_service.create_role("{0}-gw-".format(yarn_service_name) + str(flag),"GATEWAY", host)

    # update yarn configuration
    groupconfig = yarn_service.get_role_config_group("yarn-NODEMANAGER-BASE")
    groupconfig.update_config({
        "yarn_nodemanager_local_dirs":yarn_nodemanager_local_dirs,
        "yarn_nodemanager_log_dirs":yarn_nodemanager_log_dirs
    })

def add_spark_roles(cluster):
    spark_service_name=service_types_and_names["SPARK_ON_YARN"]
    spark_service = cluster.get_service(spark_service_name)

    for r in spark_service.get_all_roles():
        if r.type == "GATEWAY":
            spark_service.delete_role(r.name)
    flag=0
    for host in spark_gw_hosts:
        flag = flag +1
        try:
            spark_service.delete_role("{0}-gw-".format(spark_service_name) + str(flag))
            spark_service.create_role("{0}-gw-".format(spark_service_name) + str(flag),"GATEWAY", host)
        except:
            spark_service.create_role("{0}-gw-".format(spark_service_name) + str(flag),"GATEWAY", host)

def add_hive_roles(cluster):
    hive_service_name=service_types_and_names["HIVE"]
    hive_service = cluster.get_service(hive_service_name)

    for r in hive_service.get_all_roles():
        if r.type == "GATEWAY":
            hive_service.delete_role(r.name)
        if r.type == "HIVEMETASTORE":
            hive_service.delete_role(r.name)
            hive_service.create_role("HIVEMETASTORE",r.type,hive_metastoreServer_host)

    flag=0
    for host in hive_gw_hosts:
        flag = flag +1
        try:
            hive_service.create_role("{0}-gw-".format(hive_service_name) + str(flag),"GATEWAY", host)
        except:
            hive_service.delete_role("{0}-gw-".format(hive_service_name) + str(flag))
            hive_service.create_role("{0}-gw-".format(hive_service_name) + str(flag),"GATEWAY", host)


def add_zk_roles(cluster):
    zk_service_name=service_types_and_names["ZOOKEEPER"]
    zk_service = cluster.get_service(zk_service_name)

    for r in zk_service.get_all_roles():
        if r.type == "SERVER":
            zk_service.delete_role(r.name)
    flag=0
    for host in zk_add_nodes:
        flag = flag +1
        try:
            zk_service.create_role("{0}-SERVER-".format(zk_service_name) + str(flag),"SERVER", host)
        except:
            zk_service.delete_role("{0}-SERVER-".format(zk_service_name) + str(flag))
            zk_service.create_role("{0}-SERVER-".format(zk_service_name) + str(flag),"SERVER", host)
    print "add zk roles sucess"

    # update zookeeper configuration
    groupconfig = zk_service.get_role_config_group("zookeeper-SERVER-BASE")
    groupconfig.update_config({
        "dataDir":zk_data_dir
    })


def add_impala_roles(cluster):
    impala_service_name=service_types_and_names["IMPALA"]
    impala_service = cluster.get_service(impala_service_name)

    for r in impala_service.get_all_roles():
        if r.type == "IMPALAD":
            impala_service.delete_role(r.name)
        if r.type == "CATALOGSERVER":
            impala_service.delete_role(r.name)
            impala_service.create_role("IMPALA_CATALOGSERVER",r.type, impala_catalogserver_host)
    flag=0
    for host in impala_daemon_hosts:
        flag = flag +1
        try:
            impala_service.create_role("{0}-impalad-".format(impala_service_name) + str(flag),"IMPALAD", host)
        except:
            impala_service.delete_role("{0}-impalad-".format(impala_service_name) + str(flag))
            impala_service.create_role("{0}-impalad-".format(impala_service_name) + str(flag),"IMPALAD", host)

def change_hue_roles(cluster):
    hue_service_name = service_types_and_names["HUE"]
    hue_service = cluster.get_service(hue_service_name)

    for r in hue_service.get_all_roles():
        if r.type == "HUE_SERVER":
             hue_service.delete_role(r.name)
             hue_service.create_role("HUE_SERVER",r.type, hue_server_host)

    hue_service.update_config(hue_database_config)



def enable_sentry_hiveserver2(cluster):

    hive_service_name=service_types_and_names["HIVE"]
    hive_service = cluster.get_service(hive_service_name)

    hive_service.update_config({"sentry_service":sentry_service_name})

    for group in hive_service.get_all_roles():
        print group.type
        if  group.type  == "HIVESERVER2":
            group.update_config({"hiveserver2_enable_impersonation":"false"})
            print group.get_config()


def enable_sentry_impala(cluster):

    impala_service_name=service_types_and_names["IMPALA"]
    impala_service = cluster.get_service(impala_service_name)
    impala_service.update_config({"sentry_service":sentry_service_name})


def enable_sentry_hue(cluster):
    hue_service_name=service_types_and_names["HUE"]
    hue_service = cluster.get_service(hue_service_name)
    hue_service.update_config({"sentry_service":sentry_service_name})


def enable_sentry_solr(cluster):
    solr_service_name=service_types_and_names["SOLR"]
    solr_service = cluster.get_service(solr_service_name)
    if cm_version == "13":
       solr_service.update_config({"sentry_service":"none"})


def change_solr_roles(cluster):
    solr_service_name=service_types_and_names["SOLR"]
    solr_service = cluster.get_service(solr_service_name)

    for r in solr_service.get_all_roles():
        if r.type == "SOLR_SERVER":
            solr_service.delete_role(r.name)
            solr_service.create_role("SOLR_SERVER",r.type, solr_server_host)




def change_sentry_roles(cluster):
    sentry_service_name = service_types_and_names["SENTRY"]
    sentry_service = cluster.get_service(sentry_service_name)
    sentry_service.update_config(sentry_database_config)
    print sentry_service.get_config()

    for r in sentry_service.get_all_roles():
        if r.type == "SENTRY_SERVER":
            sentry_service.delete_role(r.name)
            sentry_service.create_role("SENTRY_SERVER",r.type, sentry_server_host)


def change_oozie_roles(cluster):
    oozie_service_name=service_types_and_names["OOZIE"]
    oozie_service = cluster.get_service(oozie_service_name)
    for r in oozie_service.get_all_roles():
       if r.type == "OOZIE_SERVER":
             oozie_service.delete_role(r.name)
             oozie_service.create_role("OOZIE_SERVER",r.type,oozie_server_host)
       groupconfig = oozie_service.get_role_config_group("OOZIE-OOZIE_SERVER-BASE")
       groupconfig.update_config({
         "oozie_database_password":hive_metastore_password,
         "oozie_database_type":hive_metastore_database_type,
         "oozie_database_user":"oozie",
         "oozie_database_host":hive_metastore_host})


def set_up_cluster():
    # get a handle on the instance of CM that we have running
    api = ApiResource(cm_host, cm_port, cm_username, cm_password, version=cm_version)

    # get the CM instance
    cm = ClouderaManager(api)
    cm.update_config(CM_CONFIG)
    # activate the CM trial license
    #cm.end_trial()
    try:
        cm.begin_trial()
    except Exception as e:
        pass
    # create the management service
    service_setup = ApiServiceSetupInfo(name=cm_service_name, type="MGMT")

    mgmt=cm.create_mgmt_service(service_setup)


    # install hosts on this CM instance

    cmd = cm.host_install(host_username, host_list, password=host_password, cm_repo_url=cm_repo_url)
    #mgmt=cm.create_mgmt_service(service_setup)
    print "Installing hosts. This might take a while."
    while cmd.success == None:
        sleep(5)
        cmd = cmd.fetch()

    if cmd.success != True:
        print "cm_host_install failed: " + cmd.resultMessage
        exit(0)
    print "cm_host_install succeeded"
    # first auto-assign roles and auto-configure the CM service
    cm.auto_assign_roles()
    cm.auto_configure()
    set_up_mgmt(api,cm)
    # create a cluster on that instance
    # delete_cluster(api,cluster_name)
    cluster = create_cluster(api, cluster_name, cdh_version)

    # add all our hosts to the cluster
    cluster.add_hosts(host_list)
    # get and list all available parcels
    parcels_list = []
    print "Available parcels:"
    for p in cluster.get_all_parcels():
        print '\t' + p.product + ' ' + p.version
        if p.version.startswith(cdh_version_number) and p.product == "CDH":
            parcels_list.append(p)

    if len(parcels_list) == 0:
        print "No " + cdh_version + " parcel found!"
        exit(0)
    cdh_parcel = parcels_list[0]
    for p in parcels_list:
        if p.version > cdh_parcel.version:
            cdh_parcel = p
    # download the parcel

    print "Starting parcel download. This might take a while."
    cmd = cdh_parcel.start_download()
    if cmd.success != True:
        print "Parcel download failed!"
        exit(0)

    # make sure the download finishes
    while cdh_parcel.stage != 'DOWNLOADED':
        sleep(5)
        cdh_parcel = get_parcel(api, cdh_parcel.product, cdh_parcel.version, cluster_name)

    print cdh_parcel.product + ' ' + cdh_parcel.version + " downloaded"

    # distribute the parcel
    print "Starting parcel distribution. This might take a while."
    cmd = cdh_parcel.start_distribution()
    if cmd.success != True:
        print "Parcel distribution failed!"
        exit(0)

    # make sure the distribution finishes
    while cdh_parcel.stage != "DISTRIBUTED":
        sleep(5)
        cdh_parcel = get_parcel(api, cdh_parcel.product, cdh_parcel.version, cluster_name)

    print cdh_parcel.product + ' ' + cdh_parcel.version + " distributed"

    # activate the parcel
    cmd = cdh_parcel.activate()
    if cmd.success != True:
        print "Parcel activation failed!"
        exit(0)

    # make sure the activation finishes
    while cdh_parcel.stage != "ACTIVATED":
        cdh_parcel = get_parcel(api, cdh_parcel.product, cdh_parcel.version, cluster_name)

    print cdh_parcel.product + ' ' + cdh_parcel.version + " activated"

    # inspect hosts and print the result
    print "Inspecting hosts. This might take a few minutes."

    cmd = cm.inspect_hosts()
    while cmd.success == None:
        cmd = cmd.fetch()

    if cmd.success != True:
        print "Host inpsection failed!"
        exit(0)

    print "Hosts successfully inspected: \n" + cmd.resultMessage

    # create all the services we want to add; we will only create one instance
    # of each
    for s in service_types_and_names.keys():
        service = cluster.create_service(service_types_and_names[s], s)

    # we will auto-assign roles; you can manually assign roles using the
    # /clusters/{clusterName}/services/{serviceName}/role endpoint or by using
    # ApiService.createRole()
    cluster.auto_assign_roles()
    cluster.auto_configure()



    hdfs_service_name=service_types_and_names["HDFS"]
    hdfs_service = cluster.get_service(hdfs_service_name)



    jn_role = None
    for r in hdfs_service.get_all_roles():
        if r.type == "NAMENODE":
            jn_role = r
            hdfs_service.delete_role(r.name)
            print "JOURNALNODE"
        if r.type == "DATANODE":
            print "namenode name:"+r.name
            hdfs_service.delete_role(r.name)


    nn_service_pattern = "{0}-" + hdfs_namenode_server_name
    hdfs_service.create_role(nn_service_pattern.format(hdfs_service_name), "NAMENODE",hdfs_namenode_host )

    # update namenode configuration
    namenode_service_name=service_types_and_names["HDFS"]
    namenode_service = cluster.get_service(namenode_service_name)

    groupconfig = namenode_service.get_role_config_group("HDFS-NAMENODE-BASE")

    groupconfig.update_config({
        "dfs_name_dir_list":dfs_name_dir_list
    })

    flag =0
    for host in hdfs_datanode_host :
        flag = flag + 1
        dn_service_pattern = "{0}-" + hdfs_datanode_server_name+str(flag)
        hdfs_service.create_role(dn_service_pattern.format(hdfs_service_name), "DATANODE",host)

    # update datanode configuration
    namenode_service_name=service_types_and_names["HDFS"]
    namenode_service = cluster.get_service(namenode_service_name)

    groupconfig = namenode_service.get_role_config_group("HDFS-DATANODE-BASE")
    groupconfig.update_config({
        "dfs_data_dir_list":dfs_data_dir_list
    })


    hueconfig  =  {
        "hue_webhdfs":nn_service_pattern.format(hdfs_service_name)
    }

    hue_service_name = service_types_and_names["HUE"]
    hue_service = cluster.get_service(hue_service_name)
    configs=hue_service.get_config()
    print configs
    hue_service.update_config(hueconfig)

    # this will set up the Hive and the reports manager databases because we
    # can't auto-configure those two things
    hive = cluster.get_service(service_types_and_names["HIVE"])
    hive_config = {"hive_metastore_database_host": hive_metastore_host, \
                   "hive_metastore_database_name": hive_metastore_name, \
                   "hive_metastore_database_password": hive_metastore_password, \
                   "hive_metastore_database_port": hive_metastore_database_port, \
                   "hive_metastore_database_type": hive_metastore_database_type}
    hive.update_config(hive_config)
    cluster.deploy_client_config().wait()
    # start the management service
    cm_service = cm.get_service()
    cm_service.start().wait()

    add_zk_roles(cluster)
    add_hdfs_roles(cluster)
    add_yarn_roles(cluster)
    add_hive_roles(cluster)
    add_spark_roles(cluster)
    add_hbase_roles(cluster)
    add_impala_roles(cluster)
    change_hue_roles(cluster)
    change_oozie_roles(cluster)
    change_solr_roles(cluster)

    change_sentry_roles(cluster)
    enable_sentry_hiveserver2(cluster)
    enable_sentry_impala(cluster)
    enable_sentry_hue(cluster)
    enable_sentry_solr(cluster)


    cluster.deploy_client_config().wait()

    print "base config  successfully executed !Please copy /usr/share/java to all nodes ,then execute cdh_firt_run.py"


def main():
    set_up_cluster()


if __name__ == "__main__":
    main()
