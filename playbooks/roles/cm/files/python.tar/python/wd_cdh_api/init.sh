python wd_setup_cdh.py
sh copy_share_java.sh 
python cdh_first_run.py
python  service_hdfs_enableHa.py
python  service_yarn_enableHa.py 
python service_kerbebos_enable.py
python service_ldap_enable.py
