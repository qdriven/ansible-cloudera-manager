import ConfigParser
import json


from cm_api.api_client import ApiResource
from cm_api.endpoints.cms import ClouderaManager
# Configuration

# Prep for reading config props from external file
CONFIG = ConfigParser.ConfigParser()
CONFIG.read("clouderaconfig.ini")
service_types_and_names = json.loads(CONFIG.get("CM", "service.types.and.names"))

cm_host = CONFIG.get("CM", "cm.host")
CM_HOST  =cm_host
cm_port = CONFIG.get("CM", "cm.port")
cm_version = CONFIG.get("CM", "cm.version")
host_list = CONFIG.get("CM","host.list").split(',')

cluster_name = CONFIG.get("CM","cluster.name")
cdh_version = CONFIG.get("CM","cdh.version")  # also valid: "CDH4"
cdh_version_number = CONFIG.get("CM","cdh.version.number")  # also valid: 4
hive_metastore_host = CONFIG.get("CM","hive.metastore.host")
hive_metastore_name = CONFIG.get("CM","hive.metastore.name")
hive_metastore_password = CONFIG.get("CM","hive.metastore.password")  # enter password here
hive_metastore_database_type = CONFIG.get("CM","hive.metastore.database.type")
hive_metastore_database_port = CONFIG.get("CM","hive.metastore.database.port")

cm_username = CONFIG.get("CM", "cm.username")
cm_password = CONFIG.get("CM", "cm.password")
cm_service_name = CONFIG.get("CM", "cm.service.name")
host_username = CONFIG.get("CM", "host.username")
host_password = CONFIG.get("CM", "host.password")
cm_repo_url = CONFIG.get("CM", "cm.repo.url")




hive_update_config={
    "hiveserver2_ldap_uri":CONFIG.get("HIVE", "hive.server2.authentication.ldap.url"),
    "hiveserver2_ldap_basedn":CONFIG.get("HIVE", "hive.server2.authentication.ldap.baseDN")}

hive_hs2_config_safety_valve =  "<property>" \
                                "<name>" \
                                "hive.server2.authentication" \
                                "</name>" \
                                "<value>" \
                                + CONFIG.get("HIVE", "hive.server2.authentication") + \
                                "</value>" \
                                "</property>" \
                                "<property>" \
                                "<name>" \
                                "hive.server2.authentication.ldap.url" \
                                "</name>" \
                                "<value>" \
                                + CONFIG.get("HIVE", "hive.server2.authentication.ldap.url") + \
                                "</value>" \
                                "</property>" \
                                "<property>" \
                                "<name> " \
                                "hive.server2.authentication.ldap.baseDN" \
                                "</name>" \
                                "<value>" \
                                + CONFIG.get("HIVE", "hive.server2.authentication.ldap.baseDN") + \
                                "</value>" \
                                "</property>"

hiveserver2_hosts = CONFIG.get("HDFS", "hdfs.gw.hosts").split(',')

impalad_cmd_args_safety_valve =  CONFIG.get("IMPALA", "impalad.cmd.args.safety.valve")

impalaconfig={
    "enable_ldap_auth":CONFIG.get("IMPALA", "enable.ldap.auth"),
    "impala_ldap_uri":CONFIG.get("IMPALA", "impala.ldap.uri"),
    "ldap_bind_pattern":CONFIG.get("IMPALA", "ldap.bind.pattern"),
}

hue_service_safety_valve=  CONFIG.get("HUE", "hue.service.safety.valve")
hueconfig={
    "base_dn"                      : CONFIG.get("HUE", "base.dn"),
    "bind_dn"                      : CONFIG.get("HUE", "bind.dn"),
    "user_filter"                  : CONFIG.get("HUE", "user.filter"),
    "user_name_attr"               : CONFIG.get("HUE", "user.name.attr"),
    "group_filter"                 : CONFIG.get("HUE", "group.filter"),
    "group_name_attr"              : CONFIG.get("HUE", "group.name.attr"),
    "bind_password"                : CONFIG.get("HUE", "bind.password"),
    "group_member_attr"            : CONFIG.get("HUE", "group.member.attr"),
    "search_bind_authentication"   : CONFIG.get("HUE", "search.bind.authentication"),
    "auth_backend"                 : CONFIG.get("HUE", "auth.backend"),
    "ldap_url"                     : CONFIG.get("HUE", "ldap.url"),
    "pam_auth_service"             : CONFIG.get("HUE", "pam.auth.service"),
    "ldap_username_pattern"        : CONFIG.get("HUE", "ldap.username.pattern"),
    "time_zone"                    : CONFIG.get("HUE", "time.zone"),
    "use_start_tls"                : CONFIG.get("HUE", "use.start.tls"),
    "create_users_on_login"        : CONFIG.get("HUE", "create.users.on.login"),
}

def enable_hue_ldap(cluster):

    hue_service_name = service_types_and_names["HUE"]
    hue_service = cluster.get_service(hue_service_name)

    configs=hue_service.get_config()
    print configs
    hue_service.update_config(hueconfig)
    for group in hue_service.get_all_roles():
        print group.type
        if  group.type  == "HUE_SERVER":
            group.update_config({"hue_server_hue_safety_valve":hue_service_safety_valve})
            print group.get_config()
    hue_service.restart().wait()

def enable_impala_ldap(cluster):
    impala_service_name = service_types_and_names["IMPALA"]
    impala_service = cluster.get_service(impala_service_name)

    impala_service.update_config(impalaconfig)

    impala_rcg =impala_service.get_role_config_group("{0}-IMPALAD-BASE".format(impala_service_name))
    impala_rcg.update_config({"impalad_cmd_args_safety_valve":impalad_cmd_args_safety_valve})
    impala_service.restart().wait()
    print "impala ldap config success!"


def enable_HiveServer2_ldap(cluster,cm):

    hive_service_name=service_types_and_names["HIVE"]
    hive_service = cluster.get_service(hive_service_name)
    rolesgroupname="HiveService2ldap"
    rolename  =   "{0}-HIVESERVER2-".format(hive_service_name)

    hiveservice2ldap =  hive_service.create_role_config_group(rolesgroupname,"{0}-HIVESERVERLDAP".format(hive_service_name),"HIVESERVER2")

    flag =0
    for host in hiveserver2_hosts:
        flag = flag +1
        hive_service.create_role(rolename+str(flag),"HIVESERVER2",host)
        hiveservice2ldap.move_roles([rolename+str(flag)])

    cm._cmd("generateCredentials").wait()


    print "*************************"
    for group in hive_service.get_all_roles():
        print group.type
        if  group.type  == "HIVESERVER2":
            #group.update_config({"hive_hs2_config_safety_valve":hive_hs2_config_safety_valve})
            group.update_config({"hive_hs2_config_safety_valve":hive_hs2_config_safety_valve,"hiveserver2_enable_impersonation":"false"})
            print group.get_config()

    hive_service.update_config(hive_update_config)
    hive_service.restart().wait()
    print "hive ldap configure succuss!"

def main():
    api = ApiResource(cm_host, cm_port, cm_username, cm_password, version=cm_version)
    cluster = api.get_cluster(cluster_name)
    cm = ClouderaManager(api)

    enable_HiveServer2_ldap(cluster,cm)

    enable_impala_ldap(cluster)

    enable_hue_ldap(cluster)

    cluster.deploy_client_config().wait()
    cluster.restart().wait()

    print "configure ldap finish !"




if __name__ == "__main__":
    main()
