# Licensed to Cloudera, Inc. under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  Cloudera, Inc. licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from cm_api.api_client import ApiResource
from cm_api.endpoints.clusters import ApiCluster
from cm_api.endpoints.clusters import create_cluster
from cm_api.endpoints.clusters import *
from cm_api.endpoints.parcels import ApiParcel
from cm_api.endpoints.parcels import get_parcel
from cm_api.endpoints.cms import ClouderaManager
from cm_api.endpoints.services import ApiService, ApiServiceSetupInfo
from cm_api.endpoints.services import create_service
from cm_api.endpoints.types import ApiCommand, ApiRoleConfigGroupRef
from cm_api.endpoints.role_config_groups import get_role_config_group
from cm_api.endpoints.role_config_groups import ApiRoleConfigGroup
from cm_api.endpoints.roles import ApiRole
from time import sleep

import re

# Configuration
service_types_and_names = {
    "ZOOKEEPER": "ZOOKEEPER",
    "HDFS": "HDFS",
    "MAPREDUCE": "MAPREDUCE",
    "HBASE": "HBASE",
    "OOZIE": "OOZIE",
    "HIVE": "HIVE",
    "HUE": "HUE",
    "IMPALA": "IMPALA",
    "SOLR": "SOLR",
    "SQOOP": "SQOOP"}
cm_host = "testbig1.wanda.cn"
CM_HOST  =cm_host
cm_port = 7180
host_list = ['testbig1.wanda.cn', 'testbig2.wanda.cn', 'testbig3.wanda.cn', 'testbig4.wanda.cn']
cluster_name = "Cluster1"
cdh_version = "CDH5"  # also valid: "CDH4"
cdh_version_number = "5"  # also valid: 4
hive_metastore_host = cm_host
hive_metastore_name = "metastore"
hive_metastore_password = "123456"  # enter password here
hive_metastore_database_type = "mysql"
hive_metastore_database_port = 3306
"""ger_host = cm_host
reports_manager_name = "reports_manager"
reports_manager_username = "rman"
reports_manager_password = "123456"  # enter password here
reports_manager_database_type = "mysql"
reports_manager_database_port = 3306
"""
cm_username = "admin"
cm_password = "admin"
cm_service_name = "mgmt"
host_username = "root"
host_list = ['testbig1.wanda.cn', 'testbig2.wanda.cn', 'testbig3.wanda.cn', 'testbig4.wanda.cn']
host_password = "bigdata"
cm_repo_url = "http://10.214.128.30/cm/"

CM_CONFIG = {
    'REMOTE_PARCEL_REPO_URLS': 'http://10.214.128.30/cdh/'
}
print CM_CONFIG


def set_up_cluster():
    # get a handle on the instance of CM that we have running
    api = ApiResource(cm_host, cm_port, cm_username, cm_password, version=13)

    # get the CM instance
    cm = ClouderaManager(api)
    cm.update_config(CM_CONFIG)
    exit(-1)
    # activate the CM trial license
    cm.begin_trial()
    # create the management service
    service_setup = ApiServiceSetupInfo(name=cm_service_name, type="MGMT")

    mgmt=cm.create_mgmt_service(service_setup)

    
    # install hosts on this CM instance

    cmd = cm.host_install(host_username, host_list, password=host_password, cm_repo_url=cm_repo_url)
    print "Installing hosts. This might take a while."
    while cmd.success == None:
        sleep(5)
        cmd = cmd.fetch()

    if cmd.success != True:
        print "cm_host_install failed: " + cmd.resultMessage
        exit(0)
    print "cm_host_install succeeded"
    # first auto-assign roles and auto-configure the CM service
    cm.auto_assign_roles()
    cm.auto_configure()
    # create a cluster on that instance
    # delete_cluster(api,cluster_name)
    cluster = create_cluster(api, cluster_name, cdh_version)

    # add all our hosts to the cluster
    cluster.add_hosts(host_list)
    # get and list all available parcels
    parcels_list = []
    print "Available parcels:"
    for p in cluster.get_all_parcels():
        print '\t' + p.product + ' ' + p.version
        if p.version.startswith(cdh_version_number) and p.product == "CDH":
            parcels_list.append(p)

    if len(parcels_list) == 0:
        print "No " + cdh_version + " parcel found!"
        exit(0)
    cdh_parcel = parcels_list[0]
    for p in parcels_list:
        if p.version > cdh_parcel.version:
            cdh_parcel = p
    # download the parcel

    print "Starting parcel download. This might take a while."
    cmd = cdh_parcel.start_download()
    if cmd.success != True:
        print "Parcel download failed!"
        exit(0)

    # make sure the download finishes
    while cdh_parcel.stage != 'DOWNLOADED':
        sleep(5)
        cdh_parcel = get_parcel(api, cdh_parcel.product, cdh_parcel.version, cluster_name)

    print cdh_parcel.product + ' ' + cdh_parcel.version + " downloaded"

    # distribute the parcel
    print "Starting parcel distribution. This might take a while."
    cmd = cdh_parcel.start_distribution()
    if cmd.success != True:
        print "Parcel distribution failed!"
        exit(0)

    # make sure the distribution finishes
    while cdh_parcel.stage != "DISTRIBUTED":
        sleep(5)
        cdh_parcel = get_parcel(api, cdh_parcel.product, cdh_parcel.version, cluster_name)

    print cdh_parcel.product + ' ' + cdh_parcel.version + " distributed"

    # activate the parcel
    cmd = cdh_parcel.activate()
    if cmd.success != True:
        print "Parcel activation failed!"
        exit(0)

    # make sure the activation finishes
    while cdh_parcel.stage != "ACTIVATED":
        cdh_parcel = get_parcel(api, cdh_parcel.product, cdh_parcel.version, cluster_name)

    print cdh_parcel.product + ' ' + cdh_parcel.version + " activated"

    # inspect hosts and print the result
    print "Inspecting hosts. This might take a few minutes."

    cmd = cm.inspect_hosts()
    while cmd.success == None:
        cmd = cmd.fetch()

    if cmd.success != True:
        print "Host inpsection failed!"
        exit(0)

    print "Hosts successfully inspected: \n" + cmd.resultMessage

    # create all the services we want to add; we will only create one instance
    # of each
    for s in service_types_and_names.keys():
        service = cluster.create_service(service_types_and_names[s], s)

    # we will auto-assign roles; you can manually assign roles using the
    # /clusters/{clusterName}/services/{serviceName}/role endpoint or by using
    # ApiService.createRole()
    cluster.auto_assign_roles()
    cluster.auto_configure()

    # this will set up the Hive and the reports manager databases because we
    # can't auto-configure those two things
    hive = cluster.get_service(service_types_and_names["HIVE"])
    hive_config = {"hive_metastore_database_host": hive_metastore_host, \
                   "hive_metastore_database_name": hive_metastore_name, \
                   "hive_metastore_database_password": hive_metastore_password, \
                   "hive_metastore_database_port": hive_metastore_database_port, \
                   "hive_metastore_database_type": hive_metastore_database_type}
    hive.update_config(hive_config)

    # start the management service
    cm_service = cm.get_service()
    cm_service.start().wait()

    # execute the first run command
    print "Excuting first run command. This might take a while."
    cmd = cluster.first_run()

    while cmd.success == None:
        cmd = cmd.fetch()

    if cmd.success != True:
        print "The first run command failed: " + cmd.resultMessage()
        exit(0)

    print "First run successfully executed. Your cluster has been set up!"


def main():
    set_up_cluster()


if __name__ == "__main__":
    main()

