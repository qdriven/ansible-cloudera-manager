import ConfigParser
import json
import os

from cm_api.api_client import ApiResource
from cm_api.endpoints.cms import ClouderaManager

# Configuration

# Prep for reading config props from external file
CONFIG = ConfigParser.ConfigParser()
CONFIG.read("clouderaconfig.ini")

cm_host = CONFIG.get("CM", "cm.host")
cm_port = CONFIG.get("CM", "cm.port")
cm_version = CONFIG.get("CM", "cm.version")
cluster_name = CONFIG.get("CM", "cluster.name")
cm_username = CONFIG.get("CM", "cm.username")
cm_password = CONFIG.get("CM", "cm.password")
kerberos_domain = CONFIG.get("KERBEROS", "domain")

configureForKerberosArgs = {
    "datanodeTransceiverPort": "1004",
    "datanodeWebPort": "1006"
}

clustername={
    "clusterName":cluster_name
}

principals={
        "username":CONFIG.get("KERBEROS", "username"),
        "password":CONFIG.get("KERBEROS", "password")
}

CM_CONFIG ={
    "KDC_HOST":CONFIG.get("KERBEROS", "KDC.HOST"),
    "SECURITY_REALM":kerberos_domain
}


print CM_CONFIG
print principals
"""
Mount Point: /api/vcm_version/cm/commands//api/v12/cm/commands/importAdminCredentials
Mount Point: /api/vcm_version/clusters/{clusterName}/commands/configureForKerberos
"""


def enable_kerberos():
    api = ApiResource(cm_host, cm_port, cm_username, cm_password, version=cm_version)

    cluster = api.get_cluster(cluster_name)

    print cluster_name
    print configureForKerberosArgs

    # update kerberos config
    cm = ClouderaManager(api)
    mgmt=cm.get_service()
    cm.update_config(CM_CONFIG)
    #import importKerberosPrincipal
    cluster._cmd("configureForKerberos", data=configureForKerberosArgs, params=clustername)
    cm._cmd("importAdminCredentials", params=principals).wait()
    cm._cmd("generateCredentials").wait()
    cluster.deploy_client_config().wait()
    os.system("/var/kerberos/krb5_db_prop.sh")
    cluster.restart().wait()
    cmd = mgmt.restart()
    while cmd.success == None:
        cmd = cmd.fetch()
    if cmd.success != True:
        print "config kerberos failed:"  + cmd.resultMessage
        exit(0)

    print "config kerberos successfully executed.Please enjoy it!"


def main():
    enable_kerberos()


if __name__ == "__main__":
    main()
