
from cm_api.api_client import ApiResource
from cm_api.endpoints.cms import ClouderaManager

# Configuration
cm_host = "testbig1.wanda.cn"
CM_HOST  =cm_host
cm_port = 7180
host_list = ['testbig1.wanda.cn', 'testbig2.wanda.cn', 'testbig3.wanda.cn', 'testbig4.wanda.cn']
cluster_name = "Cluster1"
cdh_version = "CDH5"  # also valid: "CDH4"
cdh_version_number = "5"  # also valid: 4
hive_metastore_host = cm_host
hive_metastore_name = "metastore"
hive_metastore_password = "123456"  # enter password here
hive_metastore_database_type = "mysql"
hive_metastore_database_port = 3306
cm_username = "admin"
cm_password = "admin"
cm_service_name = "mgmt"
host_username = "root"
host_list = ['testbig1.wanda.cn', 'testbig2.wanda.cn', 'testbig3.wanda.cn', 'testbig4.wanda.cn']
host_password = "bigdata"
cm_repo_url = "http://10.214.128.30/cm/"


service_types_and_names = {
    "ZOOKEEPER" : "ZOOKEEPER",
    "HDFS" : "HDFS",
    "MAPREDUCE" : "MAPREDUCE",
    "HBASE" : "HBASE",
    "OOZIE" : "OOZIE",
    "HIVE" : "HIVE",
    "HUE" : "HUE",
    "IMPALA" : "IMPALA",
    "SOLR" : "SOLR",
    "SQOOP" : "SQOOP" }

enableNnHaArguments = {
    "activeNnName": "HDFS-NAMENODE-330a40735d9b0f0d97a9a99d0a619a1c",
    # "activeNnName": "activeNn",
    "standbyNnName": "standbyNn",
    "nameservice": "nameservice1",
    "qjName": "qj",
    "activeFcName": "activeFc",
    "standbyFcName": "standbyFc",
    "forceInitZNode": "true",
    "clearExistingStandbyNameDirs": "true",
    "clearExistingJnEditsDir": "true"
}
#HDFS-NAMENODE-f804574fc71aa9fca72cf749683520ea
"""
doc:http://*:7180/static/apidocs/path__clusters_-clusterName-_services_-serviceName-_commands_hdfsEnableNnHa.html
"""
def enable_hdfsNn_Ha():
    api = ApiResource(cm_host, cm_port, cm_username, cm_password, version=13)

    #construct dict for hostname -> hostid
    hostname2id={}
    for host in  api.get_all_hosts():
        hostname2id[host.hostname] =host.hostId
        print host.hostname+":"+hostname2id[host.hostname]

    # get the CM instance
    cm = ClouderaManager(api)
    cluster = api.get_cluster(cluster_name)
    hdfs_service_name=service_types_and_names["HDFS"]
    hdfs_service = cluster.get_service(hdfs_service_name)

    #create role: JOURNALNODE   dfs_journalnode_edits_dir:/dfs/jn
    jn_role = None
    for r in hdfs_service.get_all_roles():
        if r.type == "JOURNALNODE":
            jn_role = r
            print "JOURNALNODE"

    if jn_role == None:
        print "No JOURNALNODE role found,now create it!"
        #hdfs_service.create_role("{0}-JOURNALNODE-BASE".format(hdfs_service_name), "JOURNALNODE",host_list[:3])


    jn_rcg =hdfs_service.get_role_config_group("{0}-JOURNALNODE-BASE".format(hdfs_service_name))

    #print jn_rcg.get_config(view='full')
    print jn_rcg.get_config()
    #jn_rcg.update_config({"dfs_journalnode_edits_dir":"/dfs/jn"})

    enableNnHaArguments["zkServiceName"]=service_types_and_names["ZOOKEEPER"]

    #standbyNnHostId  Id of the host on which new Standby NameNode will be created.
    enableNnHaArguments["standbyNnHostId"]=hostname2id[host_list[1]]

    #"jns"   :	 "array of jns    (apiJournalNodeArguments)

    jnhosts=host_list[1:4]
    enableNnHaArguments["jns"] =[]
    count=1
    for host in jnhosts:
        jn= {}
        jn["jnEditsDir"]="/dfs/jn"
        jn["jnName"] ="jn"+str(count)
        count = count+1
        jn["jnHostId"]=hostname2id[host]
        enableNnHaArguments["jns"].append(jn)
        print jn
    print enableNnHaArguments["jns"]
    
    print "*****"
    print enableNnHaArguments

    
    cmd=hdfs_service._cmd("hdfsEnableNnHa",data=enableNnHaArguments)
    while cmd.success == None:
        cmd = cmd.fetch()

    if cmd.success != True:
        print "failed"
        #print "hdfsEnableNnHa failed: " + cmd.resultMessage()
        exit(0)
    print "hdfsEnableNnHa successfully executed, please enjoy HA!"

def main():
    enable_hdfsNn_Ha()


if __name__ == "__main__":
    main()

