import ConfigParser
import ConfigParser
import json
from time import sleep
import os

from cm_api.api_client import ApiResource
from cm_api.endpoints.clusters import *
from cm_api.endpoints.cms import ClouderaManager
from cm_api.endpoints.parcels import get_parcel
from cm_api.endpoints.services import ApiServiceSetupInfo


# Configuration

# Prep for reading config props from external file
CONFIG = ConfigParser.ConfigParser()
CONFIG.read("clouderaconfig.ini")
service_types_and_names = json.loads(CONFIG.get("CM", "service.types.and.names"))

cm_host = CONFIG.get("CM", "cm.host")
cm_version=CONFIG.get("CM", "cm.version")
CM_HOST  =cm_host
cm_port = CONFIG.get("CM", "cm.port")
host_list = CONFIG.get("CM","host.list").split(',')

cluster_name = CONFIG.get("CM","cluster.name")
cdh_version = CONFIG.get("CM","cdh.version")  # also valid: "CDH4"
cdh_version_number = CONFIG.get("CM","cdh.version.number")  # also valid: 4
cm_username = CONFIG.get("CM", "cm.username")
cm_password = CONFIG.get("CM", "cm.password")

def set_up_cluster():
    # get a handle on the instance of CM that we have running
    api = ApiResource(cm_host, cm_port, cm_username, cm_password, version=cm_version)
    # create a cluster on that instance
    # delete_cluster(api,cluster_name)
    cluster = get_cluster(api, cluster_name)
    # execute the first run command
    print "Excuting first run command. This might take a while."
    cmd = cluster.first_run()

    while cmd.success == None:
        cmd = cmd.fetch()
    if cmd.success != True:
        print "The first run command failed:"
        exit(0)
    print "First run successfully executed. Your cluster has been set up!"

def main():
    set_up_cluster()


if __name__ == "__main__":
    main()


